# Rest React Playground

[Edit on StackBlitz ⚡️](https://stackblitz.com/edit/test-react-playground)

A simple test app while I'm learning [React.js](https://reactjs.org/)


## Things To Add

* Routing
* <React.Fragment> act as a root element that does not render so we can group a set of child elements within the content of another Component.

## Links to look into

* Sarach: "react .bind(this)". Review:
  - https://www.google.com/search?q=react+.bind(this)&oq=reach+.bind(&aqs=chrome.1.69i57j0l7.6690j0j7&sourceid=chrome&ie=UTF-8
  - https://www.freecodecamp.org/news/this-is-why-we-need-to-bind-event-handlers-in-class-components-in-react-f7ea1a6f93eb/