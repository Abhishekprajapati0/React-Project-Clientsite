import React from "react";
import { Bcom } from "./Bcom";
export function Acom(){
  return(<>
  <h1>I am A componenets</h1>
  <Bcom/>
  
  </>)
}