import React,{useContext} from "react";
import {data,data1} from "./App"
export function Ccom(){
  const name =  useContext(data);
  const age =  useContext(data1);
  return(<>
  <h1>I am c componenets</h1>
  <h2>{name}</h2>
  <h3>{age}</h3>
  
  
  </>)
}