import React,{createContext} from 'react';
import {Acom} from "./Acom"
const data = createContext();
const data1 = createContext();
export function App() {
  const name =  "Abhishek";
  const age = 19;
  return <>
  <data.Provider value = {name}>
    <data1.Provider value = {age}>
  <Acom/>
  </data1.Provider>
  </data.Provider>
  </>;
}
export {data,data1};
