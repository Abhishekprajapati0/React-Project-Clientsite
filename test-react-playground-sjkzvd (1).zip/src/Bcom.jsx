import React from "react";
import { Ccom } from "./Ccom";
export function Bcom(){
  return(<>
  <h1>I am B componenets</h1>
  <Ccom/>
  <hr/>
  </>)
}