import React, { useState } from 'react';

const DynamicDivs = () => {
  const [divs, setDivs] = useState([]);

  const handleAddClick = () => {
    setDivs([...divs, {}]); // Add a new div to the array
  };

  const handleRemoveClick = () => {
    if (divs.length > 0) {
      const newDivs = [...divs];
      newDivs.pop(); // Remove the last div from the array
      setDivs(newDivs);
    }
  };

  return (
    <div>
      <button onClick={handleAddClick}>Add</button>
      <button onClick={handleRemoveClick}>Remove</button>
      <div>
        {divs.map((div, index) => (
          <div key={index} className="dynamic-div">
            {/* Content of the dynamically created div */}
            This is div {index + 1}
          </div>
        ))}
      </div>
    </div>
  );
};

export default DynamicDivs;
